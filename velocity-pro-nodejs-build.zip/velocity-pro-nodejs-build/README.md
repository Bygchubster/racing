# Velocity Pro — Node.js 1:1 Build System

A professional build system that creates a TRUE 1:1 single-file HTML racing game by inlining all CSS and JavaScript assets.

## 📦 What's Included

```
velocity-pro-nodejs-build/
├── package.json          # Node.js package config
├── build-1to1.js        # Build script (inlines CSS + JS)
├── dist/
│   ├── index.html       # Source HTML template
│   ├── styles.css       # Separate CSS file
│   └── game.js          # Separate JS module
└── README.md            # This file
```

## 🚀 Quick Start

### Prerequisites
- Node.js 14+ installed

### Build Steps

1. **Install (optional - no dependencies needed)**
   ```bash
   npm install
   ```

2. **Run the build**
   ```bash
   npm run build
   ```

3. **Output**
   - Creates `velocity-pro-1to1.html` in the root directory
   - Single file with all CSS and JS inlined
   - No external dependencies
   - Ready to deploy anywhere!

## 🎮 Play the Game

After building, simply open `velocity-pro-1to1.html` in any browser!

### Controls
- ↑ / W - Accelerate
- ↓ / S - Brake  
- ← → / A D - Steer
- R - Restart

## 🛠️ How It Works

The `build-1to1.js` script:

1. Reads `dist/index.html` as the template
2. Finds all `<link rel="stylesheet">` tags and inlines CSS
3. Finds all `<script type="module" src="">` tags and inlines JS
4. Removes modulepreload hints
5. Outputs a single, self-contained HTML file

## 📝 Customization

- **Modify styles**: Edit `dist/styles.css`
- **Modify game logic**: Edit `dist/game.js`  
- **Rebuild**: Run `npm run build` again

## ✨ Features

- True 1:1 pixel rendering (800x500 canvas)
- Modular source structure
- Single-file output
- Zero runtime dependencies
- Works offline
- Easy to deploy

Enjoy racing! 🏎️💨