import fs from "fs";
import path from "path";

const distDir = path.resolve("./dist");
const htmlFile = path.join(distDir, "index.html");

if (!fs.existsSync(htmlFile)) {
  console.error("❌ dist/index.html not found. Run `npm run build` first.");
  process.exit(1);
}

let html = fs.readFileSync(htmlFile, "utf8");

/* -----------------------------
   INLINE CSS
----------------------------- */
html = html.replace(
  /<link rel="stylesheet" href="([^"]+)">/g,
  (_, href) => {
    const cssPath = path.join(distDir, href);
    if (!fs.existsSync(cssPath)) return "";
    const css = fs.readFileSync(cssPath, "utf8");
    return `<style>\n${css}\n</style>`;
  }
);

/* -----------------------------
   REMOVE MODULE PRELOADS
----------------------------- */
html = html.replace(
  /<link rel="modulepreload"[^>]*>/g,
  ""
);

/* -----------------------------
   INLINE ALL MODULE SCRIPTS
----------------------------- */
html = html.replace(
  /<script type="module" src="([^"]+)"><\/script>/g,
  (_, src) => {
    const jsPath = path.join(distDir, src);
    if (!fs.existsSync(jsPath)) {
      console.warn(`⚠️ Missing JS file: ${src}`);
      return "";
    }
    const js = fs.readFileSync(jsPath, "utf8");
    return `<script type="module">\n${js}\n</script>`;
  }
);

fs.writeFileSync("velocity-pro-1to1.html", html);
console.log("✅ TRUE 1:1 single-file HTML generated");